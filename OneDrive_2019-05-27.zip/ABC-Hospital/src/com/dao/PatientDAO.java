package com.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.bean.Doctor;
import com.bean.Patient;
import com.entity.DoctorEntity;
import com.entity.PatientEntity;

@Component
public class PatientDAO {

	@PersistenceContext
	private EntityManager em;
	
	
	
	@Transactional
	public String fixAppointment(Patient patient) {
		
		PatientEntity entity=new PatientEntity();
		entity.setPatient_id(patient.getPatient_id());
		entity.setPatient_name(patient.getPatient_name());
		entity.setPatient_gender(patient.getPatient_gender());
		entity.setPatient_contact(patient.getPatient_contact());
	    entity.setDoctor_id(patient.getDoctor_id());
		em.persist(entity);
		
		String id=entity.getDoctor_id();
		DoctorEntity docentity=em.find(DoctorEntity.class, id);
		return docentity.getDoctor_name();
		
		}
	
	
	public Integer getPatientCount(String doctor_id) {
		Query q=em.createQuery("from PatientEntity");
		List <PatientEntity> pList=q.getResultList();
		int count=0;
		Iterator it=pList.iterator();
		while(it.hasNext()) {
			PatientEntity p=(PatientEntity)it.next();
			if(doctor_id.equalsIgnoreCase(p.getDoctor_id())) {
				count++;
			}
		}
		return count;
		}
	
	
	public List<Doctor> getDoctorDetails(){
		List<Doctor> docList=new ArrayList<Doctor>();
		Query q=em.createQuery("SELECT d from DoctorEntity d");
		List<DoctorEntity> doctorList=q.getResultList();
		for(DoctorEntity doc:doctorList) {
			Doctor d=new Doctor();
			d.setDoctor_id(doc.getDoctor_id());
			d.setDoctor_name(doc.getDoctor_name());
			d.setDoctor_type(doc.getDoctor_type());
			docList.add(d);
		}
		
		return docList;
		
	}
}








