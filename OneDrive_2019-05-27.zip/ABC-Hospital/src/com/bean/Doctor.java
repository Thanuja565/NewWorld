package com.bean;

public class Doctor {

	private String doctor_id;
	public String getDoctor_id() {
		return doctor_id;
	}
	public void setDoctor_id(String doctor_id) {
		this.doctor_id = doctor_id;
	}
	public String getDoctor_name() {
		return doctor_name;
	}
	public void setDoctor_name(String doctor_name) {
		this.doctor_name = doctor_name;
	}
	public String getDoctor_type() {
		return doctor_type;
	}
	public void setDoctor_type(String doctor_type) {
		this.doctor_type = doctor_type;
	}
	private String doctor_name;
	private String doctor_type;
	
}
