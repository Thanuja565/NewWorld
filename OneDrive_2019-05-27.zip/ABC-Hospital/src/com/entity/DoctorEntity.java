package com.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="doctor")
public class DoctorEntity {

	@Id
	private String doctor_id;
	private String doctor_name;
	private String doctor_type;
	public String getDoctor_id() {
		return doctor_id;
	}
	public void setDoctor_id(String doctor_id) {
		this.doctor_id = doctor_id;
	}
	public String getDoctor_name() {
		return doctor_name;
	}
	public void setDoctor_name(String doctor_name) {
		this.doctor_name = doctor_name;
	}
	public String getDoctor_type() {
		return doctor_type;
	}
	public void setDoctor_type(String doctor_type) {
		this.doctor_type = doctor_type;
	}
	
}

