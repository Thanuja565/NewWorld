package com.Exception;

public class PatientExceedException extends Exception {

	public PatientExceedException() {
		super("Number of patients exceeded");
	}
}
