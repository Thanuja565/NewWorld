package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bean.Doctor;
import com.bean.Patient;
import com.dao.PatientDAO;
import com.Exception.PatientExceedException;

@Component
public class PatientService {

	@Autowired
	PatientDAO dao;
	
	public String fixAppointment(Patient patient) throws PatientExceedException {
		int pcount=dao.getPatientCount(patient.getDoctor_id());
		if(pcount>4) {
			throw new PatientExceedException();
		} else
			return dao.fixAppointment(patient);
		}
	
	public List<Doctor> getDoctorDetails(){
		return dao.getDoctorDetails();
		
	}
}
