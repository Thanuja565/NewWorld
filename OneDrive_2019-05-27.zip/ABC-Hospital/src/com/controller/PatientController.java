package com.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.bean.Doctor;
import com.bean.Patient;
import com.service.PatientService;

@Controller
public class PatientController {

	@Autowired
	PatientService service;
	
     @RequestMapping("/enroll.htm")
	public ModelAndView loadEnrollPage(ModelMap map)throws Exception{
		Patient patient=new Patient();
		map.addAttribute(patient);
		ModelAndView mView=new ModelAndView();
		mView.setViewName("/patientenroll");
		return mView;
		
	}
	
	@ModelAttribute("docTypeList")
	public Map<String,String> populateDoctorDetails()throws Exception {
		List<Doctor> docList=service.getDoctorDetails();
		Map<String,String> docMap=new HashMap<String,String>();
		for(Doctor doc:docList) {
			docMap.put(doc.getDoctor_id(), doc.getDoctor_type());
		}
		return docMap;
		
		
	}
	
	 @RequestMapping(value="/register.htm",method=RequestMethod.GET)
		public ModelAndView fixAppointment(@ModelAttribute Patient patient) throws Exception {
		ModelAndView mView=new ModelAndView();
		String name=null;
		try {
			name=service.fixAppointment(patient);
			mView.addObject("MESSAGE","Appointment successfully fixed, Doctor name is : " +name);
			mView.setViewName("/patientenroll");
		} catch(Exception e) {
			mView.addObject("MESSAGE","ERROR: "+e.getMessage());
			mView.setViewName("/patientenroll");
		}
		 
		 return mView;
		 
	 }
	
}
